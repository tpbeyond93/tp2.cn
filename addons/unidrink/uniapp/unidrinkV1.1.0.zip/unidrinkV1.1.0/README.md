后端体验地址：[https://demo.shop.weivee.com/admin/index/login?url=%2Fadmin](https://demo.shop.weivee.com/admin/index/login?url=%2Fadmin)

后端代码地址：[https://www.fastadmin.net/store/unidrink.html](https://www.fastadmin.net/store/unidrink.html)

#其他问题
要在manifest.json配置腾讯地图key